// src/components/layout/app-sidebar.tsx
'use client';

import {
  BookOpen,
  Briefcase,
  GraduationCap,
  Home,
  Lightbulb,
  Users,
  Shield,
  LayoutDashboard,
  Building,
  UserCheck,
  User,
  BadgeCheck,
  Wallet,
  Landmark,
  CreditCard,
  Trophy,
  FlaskConical,
  Settings,
  BookMarked,
  ClipboardCheck,
  CalendarDays,
  Link2,
  ArrowLeftRight,
  SlidersHorizontal,
  Sparkles,
  Workflow,
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';

import { Logo } from '@/components/icons/logo';
import {
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from '@/components/ui/sidebar';

type NavLink = {
  href: string;
  label: string;
  icon: React.ElementType;
  key?: string;
};

type NavGroup = {
  label?: string;
  links: NavLink[];
};

const studentCoreLinks: NavLink[] = [
  { href: '/student/dashboard', label: 'Dashboard', icon: Home },
  { href: '/student/program', label: 'My Program', icon: GraduationCap },
  { href: '/student/study-plan', label: 'Study Plan', icon: BookOpen },
  { href: '/student/ai', label: 'AI Tutor', icon: Lightbulb },
  { href: '/student/virtual-lab', label: 'Virtual Lab', icon: FlaskConical },
  { href: '/student/wallet', label: 'My Wallet', icon: Wallet },
  { href: '/student/leaderboard', label: 'Leaderboard', icon: Trophy },
  { href: '/student/community', label: 'Community', icon: Users },
  { href: '/student/jobs', label: 'Job Board', icon: Briefcase },
  { href: '/student/research', label: 'Research Hub', icon: FlaskConical },
  { href: '/student/payments', label: 'Billing', icon: Landmark },
];

const groupedLinks: Record<string, NavGroup[]> = {
  'premium-student': [{ links: studentCoreLinks }],
  student: [{ links: studentCoreLinks }],
  'freemium-student': [
    {
      links: [
        { href: '/student/dashboard', label: 'Dashboard', icon: Home },
        { href: '/student/program', label: 'My Program', icon: GraduationCap },
        { href: '/student/community', label: 'Community', icon: Users },
        { href: '/student/payments', label: 'Upgrade', icon: CreditCard },
      ],
    },
  ],
  admin: [
    {
      label: 'Overview',
      links: [
        { href: '/admin/dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { href: '/admin/system-health', label: 'System Health', icon: Shield },
        { href: '/admin/audit', label: 'Audit Logs', icon: BadgeCheck },
      ],
    },
    {
      label: 'Admissions',
      links: [
        { href: '/admin/admissions', label: 'Applications', icon: ClipboardCheck },
        { href: '/admin/intakes', label: 'Intakes', icon: CalendarDays },
        { href: '/admin/route-requests', label: 'Route Changes', icon: ArrowLeftRight },
      ],
    },
    {
      label: 'People',
      links: [
        { href: '/admin/users', label: 'User Management', icon: Users },
        { href: '/admin/lecturer-applications', label: 'Lecturer Applications', icon: UserCheck },
        { href: '/admin/consultants', label: 'Consultants', icon: UserCheck },
      ],
    },
    {
      label: 'Academics',
      links: [
        { href: '/admin/management', label: 'Academic Catalog', icon: Settings },
        { href: '/admin/curriculum', label: 'Curriculum', icon: BookMarked },
        { href: '/admin/curriculum-ops', label: 'Curriculum Operations', icon: Workflow },
        { href: '/admin/curriculum-blueprint', label: 'Degree Blueprint', icon: BookMarked },
        { href: '/admin/policies', label: 'Academic Policies', icon: SlidersHorizontal },
        { href: '/admin/assignments', label: 'Lecturer Assignments', icon: Link2 },
        { href: '/admin/exam-clinic', label: 'Exam Clinic', icon: ClipboardCheck },
      ],
    },
    {
      label: 'AI & Content',
      links: [
        { href: '/admin/ai', label: 'AI Studio', icon: Sparkles },
        { href: '/admin/reports', label: 'Reports & Analytics', icon: BookMarked },
      ],
    },
    {
      label: 'Community & Careers',
      links: [
        { href: '/admin/community', label: 'Community', icon: Users },
        { href: '/admin/jobs', label: 'Jobs', icon: Briefcase },
      ],
    },
  ],
  lecturer: [
    {
      links: [
        { href: '/lecturer/dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { href: '/lecturer/courses', label: 'Courses', icon: BookOpen },
        { href: '/lecturer/exams', label: 'Exam Bank', icon: ClipboardCheck },
        { href: '/lecturer/profile', label: 'Profile', icon: User },
        { href: '/lecturer/progress', label: 'Student Progress', icon: UserCheck },
        { href: '/lecturer/community', label: 'Community', icon: Users },
        { href: '/lecturer/research', label: 'Research Hub', icon: FlaskConical },
      ],
    },
  ],
  employer: [
    {
      links: [
        { href: '/employer/dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { href: '/employer/jobs', label: 'Job Listings', icon: Briefcase },
        { href: '/employer/research', label: 'Research', icon: FlaskConical },
        { href: '/employer/profile', label: 'Company Profile', icon: Building },
        { href: '/verify', label: 'Verify Credential', icon: BadgeCheck },
      ],
    },
  ],
};

function normalizeRole(role?: string) {
  if (role === 'enrolled') return 'premium-student';
  if (role === 'exam-officer') return 'admin';
  return role || 'premium-student';
}

function isLinkActive(pathname: string, href: string) {
  if (pathname === href) return true;
  if (href === '/student/dashboard' || href === '/admin/dashboard' || href === '/lecturer/dashboard' || href === '/employer/dashboard') {
    return false;
  }

  return pathname.startsWith(href) && href.split('/').length > 2;
}

export function AppSidebar({ role }: { role?: string }) {
  const pathname = usePathname();
  const [groups, setGroups] = useState<NavGroup[]>([]);

  useEffect(() => {
    const normalizedRole = normalizeRole(role);
    setGroups(groupedLinks[normalizedRole] || groupedLinks['premium-student']);
  }, [pathname, role]);

  return (
    <>
      <SidebarHeader className="glass-nav rounded-t-xl border-b border-sidebar-border/60">
        <div className="flex items-center gap-2">
          <Logo className="size-8 text-primary" />
          <span className="text-lg font-semibold text-primary">UnivAI</span>
        </div>
      </SidebarHeader>
      <SidebarContent className="glass-surface rounded-b-xl border border-sidebar-border/50 p-1">
        {groups.map((group, index) => (
          <SidebarGroup key={group.label || `nav-group-${index}`} className="px-1 py-1">
            {group.label ? <SidebarGroupLabel>{group.label}</SidebarGroupLabel> : null}
            <SidebarGroupContent>
              <SidebarMenu>
                {group.links.map((link) => (
                  <SidebarMenuItem key={link.key || link.href}>
                    <SidebarMenuButton
                      asChild
                      isActive={isLinkActive(pathname, link.href)}
                      tooltip={link.label}
                      className="justify-start data-[active=true]:bg-sidebar-accent/70"
                    >
                      <Link href={link.href}>
                        <link.icon className="size-5" />
                        <span>{link.label}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        ))}
      </SidebarContent>
    </>
  );
}
