'use client';

import { useActionState } from 'react';
import { useFormStatus } from 'react-dom';
import { useEffect, useRef, useState } from 'react';

import { Button } from '@/components/ui/button';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { aiTutorAction } from '@/app/actions';
import { Loader2, Sparkles } from 'lucide-react';
import { useSession } from '@/components/providers/session-provider';
import { getAiAccessPolicy } from '@/lib/ai-access';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { useAiContext } from '@/lib/ai-context';
import { getProgram } from '@/lib/api';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

interface BaseGeneratorState {
  // message can be a string (error/success) or null initially
  message: string | null; 
  // errors can be an object map (for validation) or null
  errors: { [key: string]: string[] | undefined } | null;
}

// Specific state for Quiz/Exercise Generators
interface TutorState extends BaseGeneratorState {
  answer: string | null;
}

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <Button type="submit" disabled={pending} className="w-full">
      {pending ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Thinking...
        </>
      ) : (
        'Ask AI Tutor'
      )}
    </Button>
  );
}

export default function TutorPage() {
const initialState = { message: null, answer: null, errors: null };
  const [state, dispatch] = useActionState<TutorState, FormData>(aiTutorAction, initialState);
  const formRef = useRef<HTMLFormElement>(null);
  const context = useAiContext();
  const { session } = useSession();
  const policy = getAiAccessPolicy(session?.user?.role);
  const [modules, setModules] = useState<{ id: string; title: string; semester?: number | null }[]>([]);
  const [selectedModule, setSelectedModule] = useState('');

  useEffect(() => {
    if (state.message === 'Success') {
      formRef.current?.reset();
    }
  }, [state]);

  useEffect(() => {
    const loadModules = async () => {
      try {
        const program = await getProgram();
        setModules(
          program.modules.map((module) => ({
            id: module.id,
            title: module.title,
            semester: module.semester,
          }))
        );
      } catch (error) {
        console.error('Failed to load modules', error);
      }
    };
    loadModules();
  }, []);

  const moduleContext = selectedModule
    ? modules.find((module) => module.id === selectedModule)
    : null;
  const moduleContextText = moduleContext
    ? `Module: ${moduleContext.title}${moduleContext.semester ? ` (Semester ${moduleContext.semester})` : ''}`
    : '';

  return (
    <div className="mx-auto max-w-3xl">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold">AI Tutor</CardTitle>
          <CardDescription>
            Stuck on a concept? Paste the relevant course material and ask your question. {policy.features.groundedAnswers ? 'Programme answers are grounded in approved module materials.' : ''}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {state.answer && (
            <div className="mb-6 flex items-start gap-4 rounded-lg border bg-muted/50 p-4">
               <Avatar>
                <AvatarFallback className='bg-primary text-primary-foreground'><Sparkles className="h-5 w-5"/></AvatarFallback>
               </Avatar>
              <div className="prose prose-invert max-w-none">
                <p className="text-foreground">{state.answer}</p>
              </div>
            </div>
          )}
          <form ref={formRef} action={dispatch} className="space-y-6">
            <input type="hidden" name="context" value={context} />
            <input type="hidden" name="accessTier" value={policy.tier} />
            <input type="hidden" name="moduleContext" value={moduleContextText} />
            <div className="space-y-2">
              <Label>Module Context (optional)</Label>
              <Select value={selectedModule} onValueChange={setSelectedModule}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a module to guide the tutor" />
                </SelectTrigger>
                <SelectContent>
                  {modules.map((module) => (
                    <SelectItem key={module.id} value={module.id}>
                      {module.title}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="courseMaterial">{policy.features.groundedAnswers ? 'Approved Module Material' : 'Course Material'}</Label>
              <Textarea
                id="courseMaterial"
                name="courseMaterial"
                placeholder={policy.features.groundedAnswers ? 'Paste approved module material for the tutor to use...' : 'Paste relevant text from your course here...'}
                className="min-h-32"
                required
              />
              {state.errors?.courseMaterial && (
                <p className="text-sm text-destructive">{state.errors.courseMaterial}</p>
              )}
            </div>
            <div className="space-y-2">
              <Label htmlFor="question">Your Question</Label>
              <Textarea
                id="question"
                name="question"
                placeholder="e.g., Can you explain this concept in simpler terms?"
                className="min-h-24"
                required
              />
              {state.errors?.question && (
                <p className="text-sm text-destructive">{state.errors.question}</p>
              )}
            </div>
            <SubmitButton />
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
