<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('program_modules', function (Blueprint $table) {
            $table->unsignedInteger('credits')->default(3)->after('description');
        });
    }

    public function down(): void
    {
        Schema::table('program_modules', function (Blueprint $table) {
            $table->dropColumn('credits');
        });
    }
};
